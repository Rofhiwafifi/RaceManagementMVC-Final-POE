﻿using Microsoft.AspNetCore.Mvc;
using RaceManagementMVC.Models;
using RaceManagementMVC.Services;
using System.Text.Json;

namespace RaceManagementMVC.Controllers
{
    public class AuthController : Controller
    {
        private readonly apiService _apiService;

        public AuthController(apiService apiService)
        {
            _apiService = apiService;
        }

        // GET: /Auth/Register
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        // POST: /Auth/Register
        [HttpPost]
        public async Task<IActionResult> Register(
            registerRequest request)
        {
            if (!ModelState.IsValid)
            {
                return View(request);
            }

            request.firstName =
                request.firstName.Trim();

            request.lastName =
                request.lastName.Trim();

            request.email =
                request.email.Trim()
                    .ToLowerInvariant();

            HttpResponseMessage response;

            try
            {
                response = await _apiService.PostAsync(
                    "api/auth/login", request);
            }
            catch (HttpRequestException ex)
            {
                ViewBag.Error = "Could not connect to the API: " + ex.Message;
                return View(request);
            }

            if (!response.IsSuccessStatusCode)
            {
                ViewBag.Error =
                    await response.Content.ReadAsStringAsync();

                return View(request);
            }

            return RedirectToAction("Login");
        }

        // GET: /Auth/Login
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        // POST: /Auth/Login
        [HttpPost]
        public async Task<IActionResult> Login(
            loginRequest request)
        {
            if (!ModelState.IsValid)
            {
                return View(request);
            }

            request.email =
                request.email.Trim()
                    .ToLowerInvariant();

            var response = await _apiService.PostAsync(
                "api/auth/login",
                request);

            if (!response.IsSuccessStatusCode)
            {
                ViewBag.Error =
                    "Invalid email or password.";

                return View(request);
            }

            string json =
                await response.Content.ReadAsStringAsync();

            var loginResponse =
                JsonSerializer.Deserialize<loginResponse>(
                    json,
                    new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

            if (loginResponse == null ||
                loginResponse.user == null)
            {
                ViewBag.Error =
                    "Login failed.";

                return View(request);
            }

            // Store login information in session.
            HttpContext.Session.SetString(
                "token",
                loginResponse.token);

            HttpContext.Session.SetString(
                "role",
                loginResponse.user.role);

            HttpContext.Session.SetString(
                "userId",
                loginResponse.user.userId.ToString());

            HttpContext.Session.SetString(
                "name",
                loginResponse.user.name);

            HttpContext.Session.SetString(
                "surname",
                loginResponse.user.surname);

            HttpContext.Session.SetString(
                "email",
                loginResponse.user.email);

            return RedirectToAction(
                "Index",
                "Home");
        }

        // Logout.
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();

            return RedirectToAction(
                "Login",
                "Auth");
        }
    }
}
