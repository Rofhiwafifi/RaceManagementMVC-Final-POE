﻿using Microsoft.AspNetCore.Mvc;
using RaceManagementMVC.Models;
using RaceManagementMVC.Services;
using System.Text.Json;

namespace RaceManagementMVC.Controllers
{
    public class ResultsController : Controller
    {
        private readonly apiService _apiService;

        public ResultsController(apiService apiService)
        {
            _apiService = apiService;
        }

        // Organiser: view results for an event.
        public async Task<IActionResult> Index(int eventId)
        {
            if (HttpContext.Session.GetString("role") != "Organiser")
            {
                return RedirectToAction("Login", "Auth");
            }

            if (eventId <= 0)
            {
                return BadRequest();
            }

            var response = await _apiService.GetAsync(
                $"api/events/{eventId}/results");

            if (!response.IsSuccessStatusCode)
            {
                ViewBag.Error = "Could not load event results.";
                ViewBag.EventId = eventId;

                return View(new List<resultModel>());
            }

            string json = await response.Content.ReadAsStringAsync();

            var results = JsonSerializer.Deserialize<List<resultModel>>(
                json,
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

            ViewBag.EventId = eventId;

            return View(results ?? new List<resultModel>());
        }

        // Organiser: enter a result.
        [HttpGet]
        public IActionResult Create(int eventId, int enrolmentId)
        {
            if (HttpContext.Session.GetString("role") != "Organiser")
            {
                return RedirectToAction("Login", "Auth");
            }

            var request = new createResultRequest
            {
                enrolmentId = enrolmentId
            };

            ViewBag.EventId = eventId;

            return View(request);
        }

        // Organiser: save a result through the API.
        [HttpPost]
        public async Task<IActionResult> Create(
            int eventId, createResultRequest request)
        {
            if (HttpContext.Session.GetString("role") != "Organiser")
            {
                return RedirectToAction("Login", "Auth");
            }

            if (!ModelState.IsValid)
            {
                ViewBag.EventId = eventId;
                return View(request);
            }

            var response = await _apiService.PostAsync(
                $"api/events/{eventId}/results", request);

            if (!response.IsSuccessStatusCode)
            {
                ViewBag.Error = "The result could not be saved.";
                ViewBag.EventId = eventId;

                return View(request);
            }

            TempData["Success"] = "Result saved successfully.";

            return RedirectToAction("Index", new { eventId });
        }

        // Organiser: publish a result.
        [HttpPost]
        public async Task<IActionResult> Publish(int id, int eventId)
        {
            if (HttpContext.Session.GetString("role") != "Organiser")
            {
                return RedirectToAction("Login", "Auth");
            }

            var request = new
            {
                resultStatus = "Published"
            };

            var response = await _apiService.PutAsync(
                $"api/results/{id}", request);

            if (!response.IsSuccessStatusCode)
            {
                TempData["Error"] = "The result could not be published.";
            }
            else
            {
                TempData["Success"] = "Result published successfully.";
            }

            return RedirectToAction("Index", new { eventId });
        }

        // Participant: view personal results.
        public async Task<IActionResult> MyResults()
        {
            if (HttpContext.Session.GetString("role") != "Participant")
            {
                return RedirectToAction("Login", "Auth");
            }

            var response = await _apiService.GetAsync(
                "api/users/me/results");

            if (!response.IsSuccessStatusCode)
            {
                ViewBag.Error = "Could not load your results.";

                return View(new List<resultModel>());
            }

            string json = await response.Content.ReadAsStringAsync();

            var results = JsonSerializer.Deserialize<List<resultModel>>(
                json,
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

            return View(results ?? new List<resultModel>());
        }
    }
}
