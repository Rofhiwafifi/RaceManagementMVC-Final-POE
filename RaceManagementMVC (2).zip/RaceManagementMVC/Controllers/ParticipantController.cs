﻿using Microsoft.AspNetCore.Mvc;

namespace RaceManagementMVC.Controllers
{
    public class ParticipantController : Controller
    {
        public IActionResult Index()
        {
            if (HttpContext.Session.GetString("role") != "Participant")
            {
                return RedirectToAction("Login", "Auth");
            }

            return View();
        }
    }
}