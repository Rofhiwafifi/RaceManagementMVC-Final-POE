﻿using Microsoft.AspNetCore.Mvc;
using RaceManagementMVC.Models;
using RaceManagementMVC.Services;
using System.Text.Json;

namespace RaceManagementMVC.Controllers
{
    public class EnrolmentsController : Controller
    {
        private readonly apiService _apiService;

        public EnrolmentsController(apiService apiService)
        {
            _apiService = apiService;
        }

        // Organiser: display participants enrolled in an event.
        public async Task<IActionResult> Index(int eventId)
        {
            if (HttpContext.Session.GetString("role") != "Organiser")
            {
                return RedirectToAction("Login", "Auth");
            }

            if (eventId <= 0)
            {
                return BadRequest();
            }

            var response = await _apiService.GetAsync(
                $"api/events/{eventId}/enrolments");

            if (!response.IsSuccessStatusCode)
            {
                ViewBag.Error = "Could not load event enrolments.";
                return View(new List<enrolmentModel>());
            }

            string json = await response.Content.ReadAsStringAsync();

            var enrolments = JsonSerializer.Deserialize<List<enrolmentModel>>(
                json,
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

            ViewBag.EventId = eventId;

            return View(enrolments ?? new List<enrolmentModel>());
        }

        // Participant: display the enrolment form.
        [HttpGet]
        public async Task<IActionResult> Enrol(int eventId)
        {
            if (HttpContext.Session.GetString("role") != "Participant")
            {
                return RedirectToAction("Login", "Auth");
            }

            var response = await _apiService.GetAsync(
                "api/categories");

            if (!response.IsSuccessStatusCode)
            {
                ViewBag.Error = "Could not load categories.";
                return View(new createEnrolmentRequest());
            }

            string json = await response.Content.ReadAsStringAsync();

            var categories = JsonSerializer.Deserialize<List<categoryModel>>(
                json,
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

            ViewBag.Categories = categories ?? new List<categoryModel>();
            ViewBag.EventId = eventId;

            return View(new createEnrolmentRequest());
        }

        // Participant: submit an enrolment.
        [HttpPost]
        public async Task<IActionResult> Enrol(
            int eventId, createEnrolmentRequest request)
        {
            if (HttpContext.Session.GetString("role") != "Participant")
            {
                return RedirectToAction("Login", "Auth");
            }

            if (!ModelState.IsValid || request.categoryId <= 0)
            {
                return await Enrol(eventId);
            }

            var response = await _apiService.PostAsync(
                $"api/events/{eventId}/enrolments", request);

            if (!response.IsSuccessStatusCode)
            {
                ViewBag.Error =
                    "Your enrolment could not be completed. You may already be enrolled or the category may be unavailable.";

                var categoryResponse = await _apiService.GetAsync(
                    "api/categories");

                if (categoryResponse.IsSuccessStatusCode)
                {
                    string json = await categoryResponse.Content.ReadAsStringAsync();

                    ViewBag.Categories =
                        JsonSerializer.Deserialize<List<categoryModel>>(
                            json,
                            new JsonSerializerOptions
                            {
                                PropertyNameCaseInsensitive = true
                            }) ?? new List<categoryModel>();
                }
                else
                {
                    ViewBag.Categories = new List<categoryModel>();
                }

                ViewBag.EventId = eventId;

                return View(request);
            }

            TempData["Success"] = "You have successfully enrolled in the event.";

            return RedirectToAction("MyEnrolments");
        }

        // Participant: display personal enrolments.
        public async Task<IActionResult> MyEnrolments()
        {
            if (HttpContext.Session.GetString("role") != "Participant")
            {
                return RedirectToAction("Login", "Auth");
            }

            var response = await _apiService.GetAsync(
                "api/users/me/enrolments");

            if (!response.IsSuccessStatusCode)
            {
                ViewBag.Error = "Could not load your enrolments.";
                return View(new List<enrolmentModel>());
            }

            string json = await response.Content.ReadAsStringAsync();

            var enrolments = JsonSerializer.Deserialize<List<enrolmentModel>>(
                json,
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

            return View(enrolments ?? new List<enrolmentModel>());
        }

        // Participant: cancel an enrolment.
        [HttpPost]
        public async Task<IActionResult> Cancel(int eventId)
        {
            if (HttpContext.Session.GetString("role") != "Participant")
            {
                return RedirectToAction("Login", "Auth");
            }

            var response = await _apiService.DeleteAsync(
                $"api/events/{eventId}/enrolments/me");

            if (!response.IsSuccessStatusCode)
            {
                TempData["Error"] = "Your enrolment could not be cancelled.";
            }
            else
            {
                TempData["Success"] = "Your enrolment has been cancelled.";
            }

            return RedirectToAction("MyEnrolments");
        }
    }
}
